	

					
							

function QuizNext() {
   // if ($("input[name=rg1]:checked").val() == "true") {
//        $("#result").html("<span class='txt_green txt_bold font20'>That's correct</span><br> Your friend is probably suffering from Bipolar Disorder. She is displaying severe prolonged symptoms of both mania and depression. This disorienting psychological condition is called Bipolar Disorder.");
//		$(".icon_correct").show()// introduction slide correct/incorrect icon
//		$(".icon_notcorrect").hide()
//        } else {
//        $("#result").html("<span class='txt_red txt_bold font20'>Not quite</span><br> Your friend is probably suffering from Bipolar Disorder. She is displaying severe prolonged symptoms of both mania and depression.  This disorienting psychological condition is called Bipolar Disorder.");
//		$(".icon_notcorrect").show()
//		$(".icon_correct").hide()
//        }


	if($("#chk_3").hasClass("img_check2")){
			$("#q1_incorrect").hide();
				$("#q1_correct").show();
			   $("#result3").html("<span class='txt_green txt_bold font22'>That's correct!</span><br> Your friend is probably suffering from Bipolar Disorder. She is displaying severe prolonged symptoms of both mania and depression. This disorienting psychological condition is called Bipolar Disorder.");
			   $(".icon_correct").show()// Knowledge Check � Question 1 slide correct/incorrect icon
				$(".icon_notcorrect").hide()
		}
		else{
			$("#q1_incorrect").show();
			$("#q1_correct").hide();
			   $("#result3").html("<span class='txt_red txt_bold font22'>Not quite!</span><br> Your friend is probably suffering from Bipolar Disorder. She is displaying severe prolonged symptoms of both mania and depression.  This disorienting psychological condition is called Bipolar Disorder.");
		$(".icon_notcorrect").show()
		$(".icon_correct").hide()
		}


}





//////////////////////////////Knowledge Check � Question 1 //////////////////////

//function QuizNext1() {
//
//		if($("#chk_3").hasClass("img_optcheck")){
//			
//				$("#q1_incorrect").hide();
//				$("#q1_correct").show();
//			   $("#result").html("<p class='font18'><b class='font20'>That�s correct!</b><br/><br/>You need to state your name and identify your organisation, while not asking the caller what he wants � he has already stated his intent. You need to ask him for his name, and the purpose of the call, so you can transfer the call to the concerned person.</p>");
//			 
//		}
//		else if($("#chk_2").hasClass("img_optcheck")){
//			
//				$("#q1_incorrect").show();
//				$("#q1_correct").hide();
//			   $("#result").html("<p class='font18'><b class='font20'>Not quite!</b><br/><br/>While this is a great way to answer a call, don�t make it sound as if you are not listening to the caller. He has already stated that he wishes to speak to John. You need to assure the caller that he has reached the correct organisation, and the call will be transferred to John once he identifies himself.<br/>The best thing you can say is, �Thank you for calling Kinstellar. My name is Mary. I understand that you wish to speak with John. May I know your name, please?�</p>");
//			 
//		}
//		else if($("#chk_1").hasClass("img_optcheck")){
//			
//				$("#q1_incorrect").show();
//				$("#q1_correct").hide();
//			   $("#result").html("<p class='font18'><b class='font20'>Not quite!</b><br/><br/>That would not be the best way to handle the call. You need to ensure the caller is trying to reach the correct organisation, and you also need to know who the caller is.<br/>The best thing you can say is, �Thank you for calling Kinstellar. My name is Mary. I understand that you wish to speak with John. May I know your name, please?�</p>");
//			 
//		}
//		
//
//
//}

/////////////Knowledge Check � Question 1 end///////////////////////////////////

//////////////////////////////Knowledge Check � Question 01 //////////////////////

function QuizNext01() {

		if($("#chk_10").hasClass("img_optcheck01")){
			
			   $("#result").html("<span class='txt_green txt_bold font22'>That's correct!</span><br> James can absolutely lead a normal and happy life.");
			   $(".icon_correct").show()// Knowledge Check � Question 1 slide correct/incorrect icon
				$(".icon_notcorrect").hide()
		}
		else{
			
			   $("#result").html("<span class='txt_red txt_bold font22'>That�s not correct!</span><br> Many people with bipolar disorder have successful careers, happy family lives, and satisfying relationships. Living with bipolar disorder is challenging, but with treatment, healthy coping skills, and a solid support system, you can live fully while managing your symptoms.");
		$(".icon_notcorrect").show()
		$(".icon_correct").hide()
		}


}

/////////////Knowledge Check � Question 0 end///////////////////////////////////

//////////////////////////////Knowledge Check � Question 1 //////////////////////

function QuizNext1() {

		if($("#chk_1").hasClass("img_optcheck")){
			
			   $("#result").html("<span class='txt_green txt_bold font22'>That's correct!</span><br> Bipolar Disorder is a brain disorder that causes extreme shifts in a person�s mood, energy, and ability to function.");
			   $(".icon_correct").show()// Knowledge Check � Question 1 slide correct/incorrect icon
				$(".icon_notcorrect").hide()
		}
		else{
			
			   $("#result").html("<span class='txt_red txt_bold font22'>That�s not correct!</span><br> Bipolar Disorder is not only the sad feeling or emotional reaction. It is also not the pessimistic mental state. In fact, Bipolar Disorder is unusual swings in pessimistic and optimistic moods. Hence, it can be defined as a brain disorder that causes extreme shifts in a person�s mood, energy, and ability to function.");
		$(".icon_notcorrect").show()
		$(".icon_correct").hide()
		}


}

/////////////Knowledge Check � Question 1 end///////////////////////////////////
/////////////Knowledge Check � Question 2//////////////////////////////

function QuizNext2() {

  		if(($("#chk_14").hasClass("img_check1"))){
			
			//alert("in if");
			$("#q1_incorrect").show();
			$("#q1_correct").hide();
			     $("#result").html("<span class='txt_red txt_bold font22'>That�s not correct!</span><br> In fact, you should disclose and discuss James� condition with his family and friends. Also, You should be aware that Bipolar Disorder is a long-term illness that must be carefully managed throughout the person�s life. You should know that James must continue taking medications and get the required treatment even if he is feeling better. And you should help James to understand his condition, so that he is not in a denial mode.");
		$(".icon_notcorrect").show()
		$(".icon_correct").hide()
		}
	
	
	else if(($("#chk_11").hasClass("img_check1")) && ($("#chk_12").hasClass("img_check1")) && ($("#chk_13").hasClass("img_check1"))) {
		
		//alert("in else");
		$("#q1_incorrect").hide();
		$("#q1_correct").show();
			
			   $("#result").html("<span class='txt_green txt_bold font22'>That's correct!</span><br>As a community helper you should be aware of all the following points: <br><ul><li class='ml30 mt10'>You should be aware that Bipolar Disorder is a long-term illness that must be carefully managed throughout the person�s life.</li><li class='ml30 mt10 mb10'>You should know that James must continue taking medications and get the required treatment even if he is feeling better.</li><li class='ml30'>You should help James to understand his condition, so that he is not in a denial mode.</li></ul>");
			   $(".icon_correct").show()// Knowledge Check � Question 1 slide correct/incorrect icon
				$(".icon_notcorrect").hide()
		}
	else{
		    $("#q1_incorrect").show();
			$("#q1_correct").hide();
		
		     $("#result").html("<span class='txt_red txt_bold font22'>Not quite!</span><br> In fact, you should disclose and discuss James� condition with his family and friends. Also, You should be aware that Bipolar Disorder is a long-term illness that must be carefully managed throughout the person�s life. You should know that James must continue taking medications and get the required treatment even if he is feeling better. And you should help James to understand his condition, so that he is not in a denial mode.");
		$(".icon_notcorrect").show()
		$(".icon_correct").hide()
	}
		

}
/////////////////////////Knowledge Check � Question 2 end /////////////////////////////////////

function showvideo() {
    if (video == undefined) {
        clearInterval(inter)
        }
    pos = video.currentTime / video.duration * 100;
    var a = Math.round(video.currentTime);
    var b = currentslideObject.markers[a];
    if (b != undefined) {
        if (currentslideObject.lastaction != a) {
            currentslideObject.lastaction = a;
            doAction(b)
            }
    }
    var c = $seekpath.width();
    var d = c * pos / 100;
    $seek.width(d);
    if (video.ended == true) {
        clearInterval(inter);
        $playpause.attr("src", "images/play.png");
        if (currentslideObject.autoPlay != "false") {
            doNext()
            }
    }
}
function Slide() {
    this.SlideNum;
    this.Title;
    this.SubTitle;
    this.SlideData;
    this.Note;
    this.Audio;
    this.markers = {};
    this.lastaction = -1;
    this.autoPlay = true
}
function doAction(a) {
    var b = $("#" + a.target);
    if (a.action == "show") {
        //b.fadeIn(150)
		
		/*$("#" + a.target).show();
		$("#" + a.target).animate({ opacity: 0 }, 0);
		$("#" + a.target).animate({ opacity: 1}, 'slow');
		$("#" + a.target).animate({ "left": "-=50px" }, "slow" );*/
		//$("#logo").css({'display':'block', 'opacity':'0'}).animate({'opacity':'1','left':'5%'}, 1500);
		$("#" + a.target).css({'display':'block', 'opacity':'0'}).animate({opacity:'1',right:'+0%'}, 150);
		//$("#char-01").animate({left: '350px', opacity: "1"},500);
		$('#text2:visible').animate({left: '+=200px'}, 'slow');
        } else if (a.action == "hide") {
       b.fadeOut(150)
        }
}

function audioStat() {
    if (Number(audio.duration) > 0) {
        if (audio.paused == false) {
            $playpause.attr("src", "images/play.png");
            audio.pause()
            } else {
            if (audio.currentTime != audio.duration) {
                audio.play();
                $playpause.attr("src", "images/pause.png")
                }
        }
    } else {
        if (Number(video.duration) > 0) {
            if (video.paused == false) {
                $playpause.attr("src", "images/play.png");
                video.pause()
                } else {
                if (video.currentTime != video.duration) {
                    video.play();
                    $playpause.attr("src", "images/pause.png")
                    }
            }
        }
    }
}
function showtime() {
    pos = audio.currentTime / audio.duration * 100;
    var a = Math.round(audio.currentTime);
    var b = currentslideObject.markers[a];
    if (b != undefined) {
        if (currentslideObject.lastaction != a) {
            currentslideObject.lastaction = a;
            doAction(b)
            }
    }
    var c = $seekpath.width();
    var d = c * pos / 100;
    $seek.width(d);
    if (audio.ended == true) {
        clearInterval(inter);
        $playpause.attr("src", "images/play.png");
        if (currentslideObject.autoPlay != "false") {
           // doNext()
            }
    }
}
function doPrv() {
   // alert("prev");
   
    if (currentSlide > 0) {
        renderSlide(currentSlide - 1)
        }
}
function doNext() {
   // alert("next");
   
    if (currentSlide < slides.length - 1) {
        renderSlide(currentSlide + 1)
        }
}
function doStart() {
    alert("In start");
    if (currentSlide < slides.length - 0) {
        renderSlide(currentSlide + 0)
	document.getElementById("p1").style.display="none";
        }
}


function setAudio(a) {
    if (a != "") {
        if ($.browser.msie) {
            audio.source = a + ".mp3";
            audio.src = a + ".mp3";
            audio.play()
            } else if ($.browser.mozilla) {
            audio.source = a + ".ogg";
            audio.src = a + ".ogg";
            audio.play()
            } else {
            audio.source = a + ".mp3";
            audio.src = a + ".mp3";
            audio.play()
            }
        inter = setInterval("showtime()", 10)
        } else {
        audio.source = "";
        audio.src = "";
        audio.pause();
        video = $("video").get(0);
        clearInterval(inter);
        inter = setInterval("showvideo()", 10)
        }
    $playpause.attr("src", "images/pause.png")
    }
function setSlideContent(a) {
    $slideHolder.html(a);
	$(".slidedata").fadeIn("slow");
}
    
    
function renderSlide(a) {
    $numdisp.text(a + 1 + " of " + slides.length);
    currentSlide = a;
    var b = slides[a];
    currentslideObject = b;
    setSlideContent(b.SlideData);
    setAudio(b.Audio);
    $("#notes").text(b.Note);
    $subtitle.text(b.SubTitle);
    $maintitle.text(b.Title);
    $(".slidetop").removeClass("highlight");
    $("#sl" + (currentSlide + 1)).addClass("highlight")
    // alert(a.toString());
    sc_bookmarking(a);
}
    
    
function togglesub(a) {
    $("#" + a).toggle()
    }
function XMLParser() {
    $(xmlData).find("SlideDetails").each(function(a) {
        var b = new Slide;
        slides.push(b);
        b.autoPlay = $(this).attr("autoPlay");
        b.SlideNum = $(this).find("SlideNum").text();
        b.Title = $(this).find("Title").text();
        b.SubTitle = $(this).find("SubTitle").text();
        b.SlideData = $(this).find("SlideData").text();
        b.Note = $(this).find("Note").text();
        b.Audio = $(this).find("Audio").text();
        var c = $(this).find("Title").attr("group");
        if ($("#sub" + c)[0] == undefined) {
            $("#toc").append('<div class="title" onclick="togglesub(\'sub' + c + "')\">" + b.Title + "</div>");
            var d = '<div class="slidetop" id="sl' + b.SlideNum + '" onclick="renderSlide(' + (b.SlideNum - 1) + ')">' + b.SubTitle + "</div>";
            $("#toc").append('<div class="sub" id="sub' + c + '">' + d + "</div>")
            } else {
            $("#sub" + c).append('<div class="slidetop" id="sl' + b.SlideNum + '" onclick="renderSlide(' + (b.SlideNum - 1) + ')">' + b.SubTitle + "</div>")
            }
        var e = $(this).find("sync").find("marker");
        if (e.length > 0) {
            for (m = 0; m < e.length; m++) {
                var f = $(e[m]);
                var g = {
                    time: f.attr("time"),
                    action: f.attr("action"),
                    target: f.attr("target")
                    };
                b.markers[f.attr("time")] = g
            }
        }
    });
    renderSlide(currentSlide)
    }
function swapTab(a) {
    if (a == "tab1") {
        $("#toc").css("display", "block");
        $("#notes").css("display", "none");
        $("#tab1").css("backgroundImage", "url(images/tocmenubg.png)");
        $("#tab1").css("backgroundRepeat", "no-repeat");
        $("#tab2").css("backgroundImage", "url()");
        $("#tab1").css("backgroundColor", "");
        $("#tab2").css("backgroundColor", "#0C69AF")
        } else if (a == "tab2") {
        $("#toc").css("display", "none");
        $("#notes").css("display", "block");
        $("#tab2").css("backgroundImage", "url(images/tocmenubg.png)");
        $("#tab2").css("backgroundRepeat", "no-repeat");
        $("#tab1").css("backgroundImage", "url()");
        $("#tab2").css("backgroundColor", "");
        $("#tab1").css("backgroundColor", "#0C69AF")
        }
}
function loadXML(a) {
    //alert("in load XML");
    $.get("xml/slide-data.xml", function(a) {
        xmlData = a;
        XMLParser();
        sc_initialize();
    })
    }
function togglePopup() {
    $("#popup").toggle()
    }
function intApp() {
    $slideHolder = $("#presentation");
    $slideHolder = $("#slideHolder");
    $nvbar = $("#control");
    $numdisp = $("#slidenumber");
    $next = $("#rightarrow");
    $prev = $("#leftarrow");
    $doc = $(document);
    audio = $("audio").get(0);
    xmlData = "";
    currentSlide = 0;
    currentslideObject = null;
    slides = [];
    $menu = $("#menu");
    $seekpath = $("#seekbar");
    $seek = $("#seek");
    $playpause = $("#playpause");
    video = null;
    $subtitle = $("#subtitle");
    $maintitle = $("#maintitle");
    $nvbar.css("left", 0);
    $nvbar.css("top", $doc.height() - $nvbar.height());
    $menu.css("left", 0);
    $menu.css("top", $doc.height() - $menu.height());
    $("#tab2").css("backgroundImage", "url()");
    $("#tab2").css("backgroundColor", "#0C69AF");
    var a = $subtitle.position();
    $("#popup").css("top", a.top + 280);
    $("#popup").css("left", a.left + 70);
    loadXML("")
}



$(window).on('beforeunload', function() {

    var xmlhttp;
    if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else {// code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    sc_exit()
});

       
    
    
    
$(document).ready(function() {
    intApp()
    })




