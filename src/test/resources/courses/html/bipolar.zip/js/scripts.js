$(document).ready(function ($){
		
		
		
		
/*if ($(window).width() < 639)
	{
		$(".tabimg1").live("click",function(){
			$('.tabcontent2').css("display", "none");
			$('.tabcontent1').css("display", "block");
			$('.tabcontent1').appendTo('.tabimg1');
		});
			
		$(".tabimg2").live("click",function(){
			$('.tabcontent1').css("display", "none");
			$('.tabcontent2').css("display", "block");
			$('.tabcontent2').appendTo('.tabimg2');
		});
	}
	else
	{
		$('.bg_lightgreen_texture').css("background", "black");

	}
		
		.tab-content>.active, .pill-content>.active {
		display:block
		}*/							
							
							
							
// introduction slide question
$(".btn-submit").live("click",function(){
	   	$(".popover3").fadeIn()
		$(".popoverbg3").show()
	});

$(".btn_continue2").live("click",function(){
	   	$(".popover3").fadeOut()
		$(".popoverbg3").fadeOut()
	});	

$(".btn_continue").live("click",function(){
	   	$(".popover").fadeOut()
		$(".popoverbg").fadeOut()
	});



// Causes Bipolar Disorder
$(".click_genitic").live("click",function(){
	   	$(".popover0").fadeIn()
		$(".popoverbg0").show()
	});
$(".click_Brainstructure").live("click",function(){
	   	$(".popover1").fadeIn()
		$(".popoverbg1").show()
	});
// Causes Bipolar Disorder continue button
	$(".btn_continue").live("click",function(){
	   	$(".popover1").fadeOut()
		$(".popoverbg1").fadeOut()
	});	
	
	$(".btn_continue").live("click",function(){
	   	$(".popover0").fadeOut()
		$(".popoverbg0").fadeOut()
	});	
	
// Knowledge Check � Question slide
	$(".btn_submit").live("click",function(){
	   	$(".popover").fadeIn()
		$(".popoverbg").show()
	});
	$(".btn_submit2").live("click",function(){
	   	$(".popover").fadeIn()
		$(".popoverbg").show()
	});
	
	
	

//////////////////////////////////////////////////////////////////////////////////////////////
	$( ".ico_menusmall img" ).click(function() {
		$( ".menuitems-responsive" ).toggle( );
	});
	
	$( ".menu" ).click(function() {
		$( ".menuitems" ).toggle( );
	});
	
	$( ".menuitems-responsive a" ).click(function() {
		$( ".menuitems-responsive" ).hide();
	})
	$( ".menuitems a" ).click(function() {
		$( ".menuitems" ).hide();
	})
})

 // introduction slide question
  $(".img_uncheck2").live("click",function(){
 var id = Number($(this).attr("id").split("_")[1]);
 $(".img_uncheck2").removeClass("img_check2");
  $("#chk_"+id).addClass("img_check2");
	
    });
   ////////////check box for question 01
	
 $(".img_optuncheck01").live("click",function(){
 var id = Number($(this).attr("id").split("_")[1]);
 $(".img_optuncheck01").removeClass("img_optcheck01");
  $("#chk_"+id).addClass("img_optcheck01");
	
    });
 ////////////check box for question 1
	
 $(".img_optuncheck").live("click",function(){
 var id = Number($(this).attr("id").split("_")[1]);
 $(".img_optuncheck").removeClass("img_optcheck");
  $("#chk_"+id).addClass("img_optcheck");
	
    });
 ////////////check box for question 2
 
 $(".img_uncheck1").live("click",function(){
		 $(this).toggleClass("img_check1");							 
		});
										  
 

$(document).click(function (e)
{
	var responsive_menu_wrapper = $(".menuitems-responsive");
	var menu_wrapper = $(".menuitems");

	var icon_menu = $(".ico_menusmall img")
	var menu = $(".menu img")
	
	
	if (!responsive_menu_wrapper.is(e.target) && !icon_menu.is(e.target)) 
	{
		$( ".menuitems-responsive" ).fadeOut(250);
	}
	
	if (!menu_wrapper.is(e.target) && !menu.is(e.target)) 
	{
		$( ".menuitems" ).fadeOut(250);
	}
	
});




/*$(window).resize(function()
  {
	  if ($(window).width() < 639)
	{
		alert("in if");
		$(".tabimg1").live("click",function(){
			$('.tabcontent2').css("display", "none");
			$('.tabcontent1').css("display", "block");
			$('.tabcontent1').appendTo('.tabimg1');
		});
			
		$(".tabimg2").live("click",function(){
			$('.tabcontent1').css("display", "none");
			$('.tabcontent2').css("display", "block");
			$('.tabcontent2').appendTo('.tabimg2');
		});
	}
	else
	{
		alert("in else");
		$('.tabcontent2').detach();
		$('.tabcontent1').detach();
		$('.bg_lightgreen_texture').css("background", "black");
		
		//$('.bg_lightgreen_texture').css('background-image', 'url(../images/light-greenbg.jpg)');
		//$('.pill-content').css("display", "block");
		
		/*.tab-content>.active, .pill-content>.active {
		display:block
		}
	

	  });
*/




$('audio').mediaelementplayer({
        //audio { width: 250px; margin:10px;}
        defaultAudioWidth: 300,
        // default if the user doesn't specify
        defaultAudioHeight: 30,
        // width of audio player
        audioWidth: 300,
        // height of audio player
        audioHeight: 30,
        // initial volume when the player starts
        startVolume: 1.0,
        // useful for <audio> player loops
        loop: false,
        // enables Flash and Silverlight to resize to content size
        enableAutosize: true,
        // the order of controls you want on the control bar (and other plugins below)
        features: ['playpause','progress','current','duration'],
        // Hide controls when playing and mouse is not over the video
        alwaysShowControls: false,
        // force iPad's native controls
        iPadUseNativeControls: false,
        // force iPhone's native controls
        iPhoneUseNativeControls: false, 
        // force Android's native controls
        AndroidUseNativeControls: false,
        // forces the hour marker (##:00:00)
        alwaysShowHours: false,
        // show framecount in timecode (##:00:00:00)
        showTimecodeFrameCount: false,
        // used when showTimecodeFrameCount is set to true
        framesPerSecond: 25,
        // turns keyboard support on and off for this instance
        enableKeyboard: true,
        // when this player starts, it will pause other players
        pauseOtherPlayers: true,
        // array of keyboard commands
        keyActions: []

    });
