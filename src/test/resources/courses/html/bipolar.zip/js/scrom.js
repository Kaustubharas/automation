/**
 * @author vishnu
 */

function page_state(page){
Titanium.App.fireEvent('app:webview_pevent',{page_num:page});	
	
}

function score_update(scr){
Titanium.App.fireEvent('app:webview_score',{score:scr});
}

function course_start(){
Titanium.App.fireEvent('app:webview_coursestate',{state:'1'});
}

function course_end(){
Titanium.App.fireEvent('app:webview_coursestate',{state:'2'});
}

/*HOW TO USE IN CURRENT FILE
 * FIRST INCLUDE THIS FILE IN EACH HTML FILE.
 * FOR MENU CLICK USE ABOVE FUNCTION IN FOLLOWING WAY
 * ACTUAL CODE :-<li><a href="index.html">Secene 1</a></li>
 * MODIFY CODE FOR MOBILE LMS:-<li><a href="index.html" onclick=" page_state('index.html');">Secene 1</a></li>

FOR PRIVIOUS AND NEXT BUTTON CLICK USE FOLLOWING CODE
   <td align="left" valign="middle"><a href="scene5.html" onclick="page_state('scene5.html');"><img src="images/prv-but.png" alt="" border="0" /></a></td>
   <td align="right" valign="middle"><a href="scene7.html" onclick="page_state('scene7.html');"><img src="images/nxt-but.png" alt="" border="0"  /></a></td>

FOR SCORE UPDATION
CALL score_update(scr); FUNCTION AND PASS ACTUAL SCORE AS A PARAMETER.

 
 */
