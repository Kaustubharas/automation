// JavaScript Document

		nextSlide: function() {
			alert("next called");
			//return this.scrollToSlide(this.$activeSlide.next(), "next");
			//return this.$activeSlide.next();
		}
		
		prevSlide: function() {
			alert("prev called");
			//return this.scrollToSlide(this.$activeSlide.prev(), "prev");
		}